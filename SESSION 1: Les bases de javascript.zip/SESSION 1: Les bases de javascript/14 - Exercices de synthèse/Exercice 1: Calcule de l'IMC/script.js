/*    
    1. Demandez la taille de l'utilisateur en centimètre dans un prompt
*/


/*    
    2. Demandez le poids de l'utilisateur en kg dans un prompt
*/


/* 
    3. Creez une fonction qui calcule son imc

    NB: la formule est la suivante:
    poids / ((taille * taille) /100)
*/



/*
    4. Créer une fonction qui donne une interpretation de l'imc 
    grace a une condition

    NB: 
            IMC      ||    Interpretation
        - moins de 16 => Maigreur extrême
        - moins de 19 => Maigreur
        - entre 19 et 21 => Minceur
        - entre 21 et 25 => poids normal
        - entre 25 et 30 => surcharge pondéral
        - entre 30 et 35 => obésité modéré
        - entre 35 et 40 => obésité sévère
        - plus de 40 => obésité morbide
*/




/* 
    5. Affichez l'interprétation de l'IMC dans une alerte
*/



