/* 
    1. demandez un mot de passe a l'utilisateur avec un prompt
*/



/* 
    2. creez une fonction qui utilise les condition 
    pour classer le mot de passe:

        - si le mot de passe est entre 0 et 8 caractères (8 compris)
          la fonction doit retourner "mot de passe faible"

        - si le mot de passe est entre 8 et 12 (12 compris) caractères
          la fonction doit retourner "mot de passe est moyen"

        - si le mot de passe est suppérieur à 12 caractères
          la fonction doit retourner "mot de passe est fort"
*/



/*
    3. affichez le status du mot de passe (fort, moyen ou faible)
    dans une alerte
*/

