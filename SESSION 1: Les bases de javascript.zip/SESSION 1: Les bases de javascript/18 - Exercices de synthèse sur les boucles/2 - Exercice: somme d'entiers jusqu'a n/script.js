/* 
    1. créez un prompt pour demander un nombre entier a votre 
    utilisateur 
*/


/*
    2. créer une fonction qui utilise une boucle pour additionner 
    tout les nombres entier positifs jusqu'au nombre choisir par votre 
    utilisateur
*/




/* 
    3. affichez le resultat dans une alerte
*/



