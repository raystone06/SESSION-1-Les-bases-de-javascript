
/*  Dans la même veine que l'exercice précédant 

    si le mot de passe est faible alors utilisez 
    une boucle pour recommencer, et demander un 
    nouveau mot de passe jusqu'a ce que le mot
    de passe entrer ne soit pas faible
*/

/* 
    1. après la fonction créer une boucle qui verifie
    si le mot de passe est faible
*/




/*
    2. si le mot de passe n'est pas faible affichez 
    « Votre mot de passe est acceptable ! » dans une alerte
*/




