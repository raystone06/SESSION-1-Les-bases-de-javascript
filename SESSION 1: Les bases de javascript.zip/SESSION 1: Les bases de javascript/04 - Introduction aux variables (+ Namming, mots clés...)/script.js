/* Tout d'abord, qu'est-ce que « déclarer une variable » veut dire ?:

    Il s'agit tout simplement de lui réserver un espace de stockage en
    mémoire, rien de plus. 
    Une fois la variable déclarée, vous pouvez commencer à
    y stocker des données sans problème. 

    En gros voit le faite de déclarer une variable comme le
    fait de mettre une valeur dans une boites (voir l'illustration)
*/

// il existe 3 façon de déclarer des varibles en javascript:

/* 1 - var => le mot clé 'var' permet de déclarer des variables qui 
              peuvent être réassigner, c'est l'ancienne façon de
              faire il est strictement déprécié aujourd'hui ne 
              l'utiliser sous aucun prétexte (on vas expliquer plutart) ! */


// une fois déclarer on utilise plus le mot clé pour réassigné une valeur




/* 2 - let => le mot clé 'let' permet de déclarer des variables qui 
              peuvent être réassigner,il est apparu avec ES6
              c'est cette méthode qu'il faut utiliser si on veux pouvoir
              réassigner les valeurs des variables. 
              c'est la nouvelle façon de faire */




/* 3 - const => le mot clé 'const' permet de déclarer des variables qui ne 
                peuvent pas être réassigner, c'est il est apparu avec ES6
                c'est cette méthode qu'il faut utiliser si on veux des
                valeurs qui ne change jamais. (comme son nom l'indique 
                les 'const' sont des constante) */



/* En gros imaginez qu'une fois que vous déclarer
  des variables avec const  la boite est refermé a jamais */


/* NB: Il est important de préciser que le nom d'une variable ne peut
       contenir que des caractères alphanumériques, autrement dit 
       les lettres de A à Z et les chiffres de 0 à 9 ; l'underscore (_) 
       et le dollar ($) sont aussi acceptés. 
                
       Autre chose : le nom de la variable ne peut pas commencer 
       par un chiffre et ne peut pas être constitué de mots-clés 
       utilisés par le Javascript. Par exemple, vous ne pouvez pas 
       créer une variable nommée let car vous allez constater que 
       ce mot-clé est déjà utilisé  !


       Par convention en javascript on declare les variables 
       en camel case => voiciDuCamelCase, 
       la 1ere lettre est en minuscule et chaque nouveau mot commence
       par une lettre majuscule
*/

