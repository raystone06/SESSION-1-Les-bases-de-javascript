/* Il ya 2 grandes familles de variables en javascript:

    * les types primitifs
        - Les String (ou Chaines de caractères)
        - Les Number (ou Nombre)
        - Les Boolean (ou booléens)
        - Les Null
        - Les Undefined  (ou indéfinis)
        - Les BigInt (les nombres très grands) 
        - Les Symbol

    * les types de références
        - Les Object (les objets)
        - Les Array (les tableaux)
        - Les Function (les fonctions)

*/

/* ---------------------------------
   1 - NUMBER => Le type nombre représente un nombre 
       entier ou à virgule entre -9007199254740991 
       et 9007199254740992. 
*/


// pour arrondir après la virgule => .toFixed()





/* ---------------------------------
   2 - STRING => Le type string ou chaînes
       de caractères représente, du texte. 
*/






// On peut voir la longueur de la chaîne grâce à « .length »
// syntaxe: string.length

/* on peut accéder au caractère grace a 
la bracket notation (notation au crochet) */
// syntaxe: string[numero]

//Pour accéder a la dernière lettre d'une chaine on fait


// QUELQUES ASTUCES UTILES LIÉES AUX STRING


// Compter le nombre de caractères => .lenght


// Trouver la 1er occurene d'une lettre => .indexOf("")






/* ---------------------------------
   3 - typeof => cette methode nous permet de voir le type d'une variable 
*/






/* ---------------------------------
   4 - Convertir une chaîne de caractères en nombre =>
       On utilise la méthode parseInt() sur la chaine de caractère
       exemple:
*/






/* ---------------------------------
   5 - BOOLEAN =>  le booléan est un type représentant 
       une valeur vraie(true) ou fausse(false). 
*/





/* ---------------------------------
   6 - UNDEFINED => Le type représentant une valeur non-définie,
       typiquement quand une variable n'a pas encore reçue de valeurs.
       c'est comme si on avais créer une boite et qu'on y avait encore 
       rien mis.
*/






/* ---------------------------------
   7 - NULL => Ce type réprente une valeur qui n'existe pas,
       typiquement quand on essaye d'utliser une variable non créée.
       Ça peut être aussi la valeur d'une variable qu'on a vider
*/






/* ---------------------------------
    8 - BIGINT => Ce type représente des nombres très grands.
        Il a été rajouté récemment pour palier à des problèmes assez rares. 
*/






/* ---------------------------------
   9 - SYMBOL : Un symbole est un identifiant unique qui permet 
       d’éviter des collisions entre des valeurs similaires.
       À ce stade de votre apprentissage,
       il ne vous sert à rien de vous pencher dessus.
       Donc on passe, mais vous pouvez visiter la doc:
       -
*/




/* ---------------------------------
    10 - OBJECT => Un objet est un container de propriétés représentant 
        des valeurs. On parle d'une collection de clés-valeurs. 
        (keyed collection)
        
        On appelle une propriété "méthode" lorsque sa valeur 
        est une fonction. donc pour faire simple les méthodes
        sont des fonctions s'associées à des objets 
        
        C'est un type très important, 
        qu'il faut maîtriser et qui représente une grande partie 
        du fonctionnement du langage JavaScript.
*/




// pour accéder a une des propriété on utilise la dot notation .


/* on peut aussi utiliser la bracket notation 
pour accéder a une des propriétés */

// Pour modifier la valeur d'une propriété


/* Ajouter une propriété => on fait simplement:
       nomObjet.nouvellePropriété = valeur
*/




// supprimer une propriété d'un objet =>






/* ---------------------------------
   11 - FUNCTION => Les fonctions permettent d'executer du code et 
        de retourner une valeur. Nous verrons le fonctionnement
        des fonctions en détail plus tard 
*/





/* ---------------------------------
   12 - ARRAY :  Les tableaux permettent de stocker plusieurs
        valeurs sous la forme d'une liste.
       
        En réalité les tableaux sont... également des objets ! 
        Mais alors, pourquoi les avoir créés ? Afin d'exploiter 
        certaines propriétés et méthodes très pratiques, comme 
        la propriété length, ou les méthodes .map(), .filter(), etc...
        Nous allons faire une petite introduction aux tableaux et 
        nous reviendrons très en détail sur les tableaux plus tard
        pour approfondir nos connaissances.

        Les indices ou index, c'est à dire les positions qui servent à retrouver les éléments d'un tableau, commencent à zéro !
        Cela porte à confusion quand on débute.

        const arr = ["a","b","c"]
        index         0   1   2
*/



/* pour acceder aux élements on utilise 
   la bracket notation comme pour les string */


// pour avoir la taille du tableaux => .lenght


// astuce pour sélectionner le dernier élément d'un tableau


// Ajouter un élément a la fin => push()


// Effacer la dernière valeur pop()



// pour avoir la position d'un élement => indexOf()


// Appliquer une fonction a tout les élement d'un tableau => .forEach






/* --------------------------------- 
    NB: les types sont dynamiques en javascript
    c'est a dire qu'on peux changer les types des 
    variables a tout moment  */

