/* 
    1. La boucle while.

    La boucle while exécute une instruction tant qu'une expression
    est truthy.
    
    Attention, si vous avez l'auto-save d'activé, cela peut provoquer 
    une boucle infinie qui fait bugger votre navigateur.
*/


// Créer un tableau qui contient les nombres de 1 a 10

