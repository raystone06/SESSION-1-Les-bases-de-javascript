/* 
    1. Les fonctions.
    
    Les fonctions permettent d'executer du code et de retourner une valeur.
    On peut leur passer des arguments qui correspondent aux paramètres 
    de la fonction. Ces paramètres sont des variables locales, 
    utilisables seulement dans le corps de cette fonction.

    - Pour créer une fonction la syntaxe c'est: 

    function nomFonction(paramètre){
        instructions
    } 


    - pour exercuter la fonction il suffit juste de l'appeler:
    nomFonction(paramètre)


*/

// exmple: créons une fonction qui fait l'addition

//appelons la fonction:



/* 
    2. Les fonctions fléchées

    Ces fonctions ont été rajoutées en 2015 en JavaScript (ES6).
    Elles ont une syntaxe plus courte et quelques différences 
    avec les fonctions classiques.
    On verras les fonction fléchées plus en details plus tard


    pour appeller une fonction fléché on fait:

    const nomFonction = (paramètres) => {
        instructions
    }
*/

//exemple créons une fonction qui fait des soustraction





/*
    NB pour les fonctions fléchées les paranthéses ne sons pas obligatoires
    si il n'y a qu'un seul paramètres et si il n'y a qu'une instruction
    les collades et le mot clé return ne sont pas obligatoires 

*/

//exemple: une fonction qui fait la multiplication:


//exemple: une fonction qui donne le carré d'un nombre


