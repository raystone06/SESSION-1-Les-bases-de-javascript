

/* 
   1. LA SYNTAXE DE JAVASCRIPT
   La syntaxe du Javascript n'est pas compliquée, 
   voir (l'image 1)

   le point-virgule n'est pas obligatoire si l'instruction
   qui suit se trouve sur la ligne suivante, comme 
   dans l'exemple de l'image 1.

   En revanche, si vous écrivez plusieurs instructions 
   sur une même ligne, comme dans l'exemple de l'image 2, 
   le point-virgule est obligatoire. 

   Si le point-virgule n'est pas mis, l'interpréteur
   ne va pas comprendre qu'il s'agit d'une autre instruction 
   et risque deretourner une erreur.

   On verras la syntaxe plus en détails au cours de la formation !

*/

// 2. LES COMMENTAIRES

// => commentaires sur une ligne

/* => commentaires sur 
    plusieurs lignes */

/* le raccourcis « CTRL + / » ou « CTRL + k-u »
   pour faire des commentaires 
   (et dans tous les langages) */



