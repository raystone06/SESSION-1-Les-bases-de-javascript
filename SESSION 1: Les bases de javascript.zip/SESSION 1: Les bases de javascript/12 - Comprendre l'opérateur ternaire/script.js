/* 
    1. L'opérateur ternaire.

    L'opérateur ternaire permet d'effectuer une condition dans une 
    expression. il fonctionne comme un if...else :

    (condition) ? instruction si vrai : instruction si faux

*/
