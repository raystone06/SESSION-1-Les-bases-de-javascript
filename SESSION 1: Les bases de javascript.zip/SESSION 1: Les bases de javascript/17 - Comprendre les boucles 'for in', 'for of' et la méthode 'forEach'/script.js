/* 
    Les boucles modernes for...in et for...of (ES6)
    NB: itérer => Répéter, faire une seconde fois.
*/

// 1. for...in sert à itérer à travers des objets.


/* 2. for...of sert à parcourir à des éléments itérables,
   comme les tableaux ou les chaînes de caractères. 
*/


/* 3. La méthode forEach (pour chaque) => Elle permet d'itérer 
   sur les éléments d'un tableau et d'appliquer une fonction de 
   rappel à chaque élément.

   Cette méthode simplifie le processus de parcours d'un tableau en 
   comparaison avec l'utilisation d'une boucle for traditionnelle.
*/

