/* 
    1. L'instruction if est la structure de test la plus basique,
    on la retrouve dans tous les langages (avec une syntaxe parfois
    différente d'un langage à l'autre...). Elle permet d'exécuter une
    série d'instructions (un bloc d'instructions) si jamais une condition
    est réalisée.
    
    Une instruction if s'exécute si l'expression de sa condition 
    est évaluée comme à true.

    Chaque valeur JavaScript est soit truthy soit falsy.

    Comme moyen mnémotechnique pour vous aider à comprendre, 
    on peut dire qu'une valeur truthy est une valeur qui 'existe' 
    et qu'une valeur falsy est une valeur qui 'n'existe pas'.
    
    Exemples de valeur truthy : true, "abc", 10, [1,2,3], -999, etc...

    Toutes les valeurs falsy : undefined, null, NaN, 0,
    "" (chaîne vide), false.

    Pour savoir si une valeur est vrai ou fausse on peut utiliser
    la méthode: Boolean(valeur)
*/




/* 
    2. L'instruction if dans sa forme basique ne permet de tester qu'une 
    condition, or la plupart du temps on aimerait pouvoir choisir les 
    instructions à exécuter en cas de non réalisation de la condition... 
    L'expression if ... else permet d'exécuter une autre série 
    d'instruction en cas de non-réalisation de la condition.

    Parfois, on a besoin d'enchaîner plusieurs conditions afin 
    d'exécuter différentes actions en fonction de différentes conditions;

    On peut donc utiliser les instructions else if(condition){} ou else{}.

    else if(condition){}  est utilisée lorsqu'on a besoin de 
    vérifier une autre condition.

    else{} est utilisé à la fin d'une suite de conditions, lorsqu'on 
    veut exécuter une instruction pour l'ensemble des conditions restantes.
*/


