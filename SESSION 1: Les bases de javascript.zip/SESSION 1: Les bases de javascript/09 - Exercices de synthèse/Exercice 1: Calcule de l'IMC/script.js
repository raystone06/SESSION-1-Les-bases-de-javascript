
/*    
    1. Demandez la taille de l'utilisateur en mètre dans un prompt
*/




/*    
    2. Demandez le poids de l'utilisateur en kg dans un prompt
*/



/* 
    3. Creez une fonction qui calcule son imc

    NB: la formule est la suivante:
    poids / taille * taille
*/





/* 
    3. Affichez l'IMC obtenue dans une alerte
*/



