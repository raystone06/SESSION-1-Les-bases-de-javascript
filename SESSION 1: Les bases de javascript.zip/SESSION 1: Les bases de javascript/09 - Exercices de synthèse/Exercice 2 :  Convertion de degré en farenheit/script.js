/*    
    1. Demandez la temperature en degré Celsius a l'utilisateur 
    dans un prompt
*/


 
/* 
    2. Creez une fonction qui converti la température entrée en Celsius
    en degré farenheit

    nb: la formule de convertion est la suivante:
    (degréCelsius * (9/5) + 32) 
*/

  

/* 
    3. Affichez la temperature obtenue dans une alerte
*/

  