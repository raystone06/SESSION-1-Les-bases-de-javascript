/* 
    En JavaScript, les opérateurs servent à effectuer des calculs, 
    assigner ou réassigner des valeurs, comparer, etc ... 

    Exemple : 5 + 10
    5 et 10 sont des opérandes, et + est un opérateur d'addition.

    Découvrons les principaux opérateurs.
*/

/* 
    1.  Les opérateurs mathématiques (ou opérateur de calcule)

        + =>  Addition
        - =>  Soustraction
        () => Parenthèses 
        * =>  Multiplication
        / =>  Division 
        % =>  Modulo 
        ** => Exponentiel

        NB: modulo est le reste de la division entière
        exemple 5 % 2 = 1

*/



/* 
    2. Les opérateurs de comparaison.

    Comparent deux opérandes et sont évalués à true ou false.

    >   Supériorité stricte.
    <   Infériorité stricte.
    <=  Inférieur ou égal.
    >=  Supérieur ou égal.
*/



/* 
    3. Les opérateurs d'égalité.

    Comparent l'égalité ou l'inégalité de deux opérandes et sont évalués true ou false.

    ==   Égalité simple.(pas recommandé)
    !=   Inégalité simple. (pas recommandé)
    ===  Égalité stricte.
    !==  Inégalité stricte.

*/



/* 
    4. Les opérateurs d'affectation.

    Permettent d'affecter des valeurs après un calcul.

    
    ++, ex num++ équivaut à num = num + 1 // 11
    --, ex num-- équivaut à num = num - 1 // 9
    +=, ex num += 20 équivaut à num = num + 20 // 30
    -=, ex num -= 20 équivaut à num = num - 20 // -10
    *=, ex num *= 10 équivaut à num = num * 10 // 100
    
*/




/*
    Il existe beaucoup d'opérateurs plus confidentiels, 
    mais il n'est pas utile de tous les passer en revue à 
    ce stade de votre apprentissage.
*/



// LA CONCATÉNATION

/* 1. 
    Certains opérateurs ont des particularités cachées. 
    Prenons l'opérateur + ; en plus de faire des additions, 
    il permet de faire ce que l'on appelle des concaténations 
    entre des chaînes de caractères. 
    
    Une concaténation consiste à ajouter une chaîne de 
    caractères à la fin d'une autre, comme dans cet exemple.
*/


// autre exemple


// exmple avec le "+="


/*  2. 

    Les templates litterals (ou littéraux de gabarit en français) 
    
    pour faire des templates litterals on utilise les backticks 
    (alt gr + 7) => ` `,
    et on peut utiliser les variables ou les expression js avec
    ${expression}
*/



