/* 
    Qu'est-ce qu'une boîte de dialogue?: 

    Une boîte de dialogue est une fenêtre qui s'affiche au premier plan,
    et qui permet a l'utilisateur d'interagir avec la page soit pour
        - Avertir l'utilisateur
        - Confronter l'utilisateur à un choix
        - lui demander de compléter un champ pour récupérer une information.
*/

/* 1. la méthode alert() => permet d'afficher dans une boîte toute simple
      composée d'une fenêtre, d'un bouton OK et du texte qu'on lui 
      fournit en paramètre. Dès que cette boîte est affichée,
      l'utilisateur n'a d'autre alternative que de cliquer sur le bouton OK.
*/



/* 2. La méthode confirm() => similaire à la méthode alert(), 
      si ce n'est qu'elle permet un choix entre "OK" et "Annuler". 
      Lorsque l'utilisateur appuie sur "OK" la méthode renvoie la valeur
      true. Elle renvoie false dans le cas contraire...
*/



/* 3. La méthode prompt => fournit un moyen simple de récupérer une information 
      provenant de l'utilisateur, on parle alors de boîte d'invite. 
      La méthode prompt() prend deux arguments:
      •le texte d'invite
      •la chaîne de caractères par défaut dans le champ de saisie (pas obligatoire)
      comme ça : prompt("quel est ton nom ?", "chaine par défaut")
*/



/* on peut stocker les valeurs des prompts dans des variables 
      exemple:
*/




